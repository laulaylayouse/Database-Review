package com.example.recipeapproom_laila

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var EditText_Title: EditText
    lateinit var EditText_Author: EditText
    lateinit var EditText_Ingredents: EditText
    lateinit var EditText_Instruction: EditText

    lateinit var Button_Save: Button
    lateinit var Button_View: Button

    val recipesDB by lazy {RecipesDatabase.getInstance(applicationContext).recipesDao() }

    var title = ""
    var author = ""
    var ingredients = ""
    var instructions = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        EditText_Title = findViewById(R.id.EditText_Title)
        EditText_Author = findViewById(R.id.EditText_Author)
        EditText_Ingredents = findViewById(R.id.EditText_Ingredents)
        EditText_Instruction = findViewById(R.id.EditText_Instruction)

        Button_Save = findViewById(R.id.Button_Save)
        Button_View = findViewById(R.id.Button_View)

        Button_Save.setOnClickListener {
            title = EditText_Title.text.toString()
            author = EditText_Author.text.toString()
            ingredients = EditText_Ingredents.text.toString()
            instructions = EditText_Instruction.text.toString()
            if (title.isNotEmpty() && author.isNotEmpty() && ingredients.isNotEmpty() && instructions.isNotEmpty()) {

                RecipesDatabase.getInstance(applicationContext).recipesDao().insertRecipe(Table_Recipes(0,title, author, ingredients, instructions))
                Toast.makeText(this, "New Recipe is added!!", Toast.LENGTH_LONG).show()
                EditText_Title.setText("")
                EditText_Author.setText("")
                EditText_Ingredents.setText("")
                EditText_Instruction.setText("")

            }
            else
            {
                Toast.makeText(this, "Please Enter a Recipe Correctly", Toast.LENGTH_LONG).show()
            }

        }
        Button_View.setOnClickListener {
            val intent = Intent(this, ViewActivity::class.java)
            startActivity(intent)
        }


    }
}